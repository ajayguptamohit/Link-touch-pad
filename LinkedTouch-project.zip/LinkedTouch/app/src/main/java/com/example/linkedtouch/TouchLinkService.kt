package com.example.linkedtouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class TouchLinkService : AccessibilityService() {

    private val chunkMs = 30L
    private val size = 140

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private var overlay: View? = null
    @Volatile private var held = false
    private var bx = 800f
    private var by = 900f

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> buildOverlay() }

    private fun pathB() = Path().apply { moveTo(bx, by) }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(listener)
        buildOverlay()
    }

    private fun buildOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val ax = prefs.getInt("ax", 200)
        val ay = prefs.getInt("ay", 900)
        bx = prefs.getInt("bx", 800).toFloat()
        by = prefs.getInt("by", 900).toFloat()

        val v = View(this).apply {
            setBackgroundColor(Color.argb(90, 255, 0, 0))
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> pressB()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> held = false
                }
                true
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ax - size / 2
            y = ay - size / 2
        }
        wm.addView(v, lp)
        overlay = v
    }

    private fun pressB() {
        held = true
        send(StrokeDescription(pathB(), 0, chunkMs, true))
    }

    private fun send(stroke: StrokeDescription) {
        val g = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                if (held) send(stroke.continueStroke(pathB(), 0, chunkMs, true))
                else send(stroke.continueStroke(pathB(), 0, 1, false))
            }
        }, null)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { held = false }
    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
