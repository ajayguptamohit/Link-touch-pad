package com.example.linkedtouch

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }
        fun field(label: String, key: String, def: Int): EditText {
            root.addView(TextView(this).apply { text = label })
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(p.getInt(key, def).toString())
            }
            root.addView(e)
            return e
        }
        val ax = field("Point A - X (pixel)", "ax", 200)
        val ay = field("Point A - Y (pixel)", "ay", 900)
        val bx = field("Point B - X (pixel)", "bx", 800)
        val by = field("Point B - Y (pixel)", "by", 900)

        root.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                p.edit()
                    .putInt("ax", ax.text.toString().toIntOrNull() ?: 200)
                    .putInt("ay", ay.text.toString().toIntOrNull() ?: 900)
                    .putInt("bx", bx.text.toString().toIntOrNull() ?: 800)
                    .putInt("by", by.text.toString().toIntOrNull() ?: 900)
                    .apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Accessibility service ON karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "\nSettings > Accessibility > Linked Touch ko ON karo. Laal square = Point A."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
